<?php

namespace MauticPlugin\MauticCrmBundle\Integration\Salesforce\Exception;

class NoObjectsToFetchException extends \Exception
{
}
