<?php

namespace MauticPlugin\MauticFocusBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

class MauticFocusBundle extends PluginBundleBase
{
}
