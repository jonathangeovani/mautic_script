<?php

namespace MauticPlugin\MauticTagManagerBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

class MauticTagManagerBundle extends PluginBundleBase
{
}
