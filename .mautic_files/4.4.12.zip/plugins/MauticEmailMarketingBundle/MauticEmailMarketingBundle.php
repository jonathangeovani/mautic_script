<?php

namespace MauticPlugin\MauticEmailMarketingBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

/**
 * Class MauticEmailMarketingBundle.
 */
class MauticEmailMarketingBundle extends PluginBundleBase
{
}
