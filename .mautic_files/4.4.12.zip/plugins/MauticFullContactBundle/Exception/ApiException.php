<?php

namespace MauticPlugin\MauticFullContactBundle\Exception;

class ApiException extends BaseException
{
}
