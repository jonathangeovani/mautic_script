<?php

namespace MauticPlugin\MauticFullContactBundle\Exception;

use Exception;

class BaseException extends Exception
{
}
