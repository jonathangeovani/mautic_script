<?php

namespace MauticPlugin\MauticFullContactBundle\Exception;

class NotImplementedException extends BaseException
{
}
