<?php

namespace MauticPlugin\MauticClearbitBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

class MauticClearbitBundle extends PluginBundleBase
{
}
