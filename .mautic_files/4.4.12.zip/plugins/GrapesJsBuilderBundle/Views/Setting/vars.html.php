<textarea id="grapesjsbuilder_assets" class="hide" data-upload="<?php echo $dataUpload; ?>" data-delete="<?php echo $dataDelete; ?>"><?php echo $assets; ?></textarea>
